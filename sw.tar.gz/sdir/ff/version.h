#ifndef FF_VERSION_HPP
#define FF_VERSION_HPP

#define FF_MAJOR_VERSION 2
#define FF_MINOR_VERSION 2
#define FF_BETA_VERSION  0
#define FF_VERSION "2.2.0"

#endif /* FF_VERSION_HPP */
